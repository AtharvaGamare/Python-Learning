"Task 1 : Perform Basic Mathematical Operations"

num1 = input("Enter the First number: ")
num2 = input("Enter the Second number: ")

Addition = int(num1) + int(num2)
print("Addition:",Addition)

Subtraction = int(num1) - int(num2)
print("Subtraction:", Subtraction)

Multiplication = int(num1) * int(num2)
print("Multiplication:", Multiplication)

Division = int(num1) / int(num2)
print("Division:", Division)