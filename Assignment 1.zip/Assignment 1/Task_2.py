"Task 2 : Create a Personalized Greeting"

firstname = input("Enter your First Name:")
lastname = input("Enter your Last Name:")
print("Hello,", firstname + " " + lastname, "! Welcome to the python program.")